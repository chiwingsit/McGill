#define BOOLEAN int
BOOLEAN valid(char username[50], char password[50]);
