extern int shift;
void encrypt(char text[50]);
void decrypt(char text[50]);
